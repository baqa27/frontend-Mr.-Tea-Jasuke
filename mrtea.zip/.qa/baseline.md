## typecheck (exit 1)

> mrtea-jasuke-frontend@0.1.0 typecheck
> tsc -p tsconfig.app.json --noEmit

src/features/owner-home/OwnerHomePage.tsx(47,17): error TS6133: 'bahan' is declared but its value is never read.
src/features/owner-home/OwnerHomePage.tsx(104,10): error TS6133: 'MenuTerlaris' is declared but its value is never read.
src/features/owner-home/OwnerHomePage.tsx(110,10): error TS6133: 'BelanjaBesok' is declared but its value is never read.


## lint (exit 0)
src/features/owner-home/OwnerHomePage.tsx:104:10: warning eslint(no-unused-vars): Function 'MenuTerlaris' is declared but never used. help: Consider removing this declaration.
src/features/owner-home/OwnerHomePage.tsx:110:10: warning eslint(no-unused-vars): Function 'BelanjaBesok' is declared but never used. help: Consider removing this declaration.
src/features/owner-home/OwnerHomePage.tsx:29:30: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/owner-home/OwnerHomePage.tsx:32:94: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/owner-home/OwnerHomePage.tsx:89:25: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/owner-home/OwnerHomePage.tsx:90:35: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/pos/Nota.tsx:24:238: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/recap/RecapDetailPage.tsx:20:39: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/master/MenuMasterPage.tsx:152:17: warning react(incompatible-library): Use of incompatible library help: This API returns functions which cannot be memoized without leading to stale UI. To prevent this, by default React Compiler will skip memoizing this component/hook. However, you may see issues if values from this API are passed to other components/hooks that are memoized
src/features/orders/OrdersPage.tsx:25:55: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/orders/OrdersPage.tsx:52:75: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/recap/RecapListPage.tsx:15:25: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders
src/features/recap/RecapListPage.tsx:16:35: warning react(purity): Cannot call impure function during render help: `Date` is an impure function. Calling an impure function can produce unstable results that update unpredictably when the component re-renders


## test (exit 0)

> mrtea-jasuke-frontend@0.1.0 test
> vitest run


 RUN  v5.1.0 D:/dicoding asah/mrtea-frontend


 Test Files  10 passed (10)
      Tests  89 passed (89)
   Start at  11:59:17
   Duration  7.49s (environment 57%, import 19%, setup 13%, tests 9%, transform 1%, worker 1%)



## build (exit 1)

> mrtea-jasuke-frontend@0.1.0 build
> tsc -b && vite build

src/features/owner-home/OwnerHomePage.tsx(47,17): error TS6133: 'bahan' is declared but its value is never read.
src/features/owner-home/OwnerHomePage.tsx(104,10): error TS6133: 'MenuTerlaris' is declared but its value is never read.
src/features/owner-home/OwnerHomePage.tsx(110,10): error TS6133: 'BelanjaBesok' is declared but its value is never read.


